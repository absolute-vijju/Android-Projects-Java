package com.example.retrofit_registration;

public class Contacts
{
    String doc_username;
    String doc_passwd;

    public String getDoc_username() {
        return doc_username;
    }

    public void setDoc_username(String doc_username) {
        this.doc_username = doc_username;
    }

    public String getDoc_passwd() {
        return doc_passwd;
    }

    public void setDoc_passwd(String doc_passwd) {
        this.doc_passwd = doc_passwd;
    }
}
