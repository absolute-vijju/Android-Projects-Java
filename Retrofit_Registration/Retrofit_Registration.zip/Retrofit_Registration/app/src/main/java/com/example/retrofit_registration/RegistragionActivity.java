package com.example.retrofit_registration;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class RegistragionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registragion);
    }
}
