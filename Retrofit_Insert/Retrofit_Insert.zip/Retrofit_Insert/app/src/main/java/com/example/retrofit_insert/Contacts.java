package com.example.retrofit_insert;

public class Contacts {
    String doc_username;
    String doc_passwd;

    String response;

    public String getResponse() {
        return response;
    }
}
