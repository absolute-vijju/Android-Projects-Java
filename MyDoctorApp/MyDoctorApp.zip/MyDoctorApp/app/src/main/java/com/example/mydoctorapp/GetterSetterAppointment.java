package com.example.mydoctorapp;

public class GetterSetterAppointment {
    String doc_id, pat_id, time, date, status, response;

    public String getResponse() {
        return response;
    }
}
