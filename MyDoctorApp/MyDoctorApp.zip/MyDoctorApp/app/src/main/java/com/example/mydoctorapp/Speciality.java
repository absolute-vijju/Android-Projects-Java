package com.example.mydoctorapp;

public class Speciality {
    String spec_type;

    public String getSpec_type() {
        return spec_type;
    }

    public void setSpec_type(String spec_type) {
        this.spec_type = spec_type;
    }
}
