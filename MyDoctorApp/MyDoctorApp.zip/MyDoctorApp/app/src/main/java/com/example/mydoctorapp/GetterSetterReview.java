package com.example.mydoctorapp;

public class GetterSetterReview {
    String doc_id, pat_id, review, response;
    float rating;

    public String getResponse() {
        return response;
    }
}
