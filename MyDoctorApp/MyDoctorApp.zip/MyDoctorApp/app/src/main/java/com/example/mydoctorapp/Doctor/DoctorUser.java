package com.example.mydoctorapp.Doctor;

public class DoctorUser {
    String doc_fname, doc_lname, doc_gender,doc_cliaddress, doc_phone, doc_dob, doc_speciality, doc_degree, doc_username, doc_passwd, response;

    public String getResponse() {
        return response;
    }
}
