package com.example.mydoctorapp;

public class GetterSetterUpdate {
    String app_id, status;
    String response;

    public String getResponse() {
        return response;
    }
}
