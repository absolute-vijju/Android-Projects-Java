package com.example.mydoctorapp.Doctor;

public class GetterSetterDocTime {
    String doc_id;
    String monday, tuesday, wednesday, thursday, friday, saturday;
    String response;

    public String getResponse() {
        return response;
    }
}
