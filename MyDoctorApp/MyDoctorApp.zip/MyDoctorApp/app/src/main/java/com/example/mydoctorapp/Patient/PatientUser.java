package com.example.mydoctorapp.Patient;

public class PatientUser {
    String pat_fname, pat_lname, pat_gender, pat_phone, pat_dob, pat_username, pat_passwd, response;

    public String getResponse() {
        return response;
    }
}
